package de.huesync.tv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

data class Channel(val id: Int, val x: Double, val y: Double)
data class Zone(val id: String, val name: String, val channels: List<Channel>)

/**
 * Hue-Bridge-REST-Zugriff (API v1 fürs Pairing, v2 für Entertainment-Bereiche).
 * Die Bridge nutzt ein selbstsigniertes Zertifikat, daher wird es nur für Bridge-Aufrufe im LAN akzeptiert.
 */
object Hue {
    private val JSON = "application/json".toMediaType()

    private val bridgeClient: OkHttpClient by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), SecureRandom()) }
        OkHttpClient.Builder()
            .sslSocketFactory(ctx.socketFactory, tm)
            .hostnameVerifier { _, _ -> true }
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private val plainClient = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).build()

    /** Sucht die Bridge über den Hue-Discovery-Dienst. */
    suspend fun discover(): String? = withContext(Dispatchers.IO) {
        runCatching {
            plainClient.newCall(Request.Builder().url("https://discovery.meethue.com").build()).execute().use {
                JSONArray(it.body!!.string()).getJSONObject(0).getString("internalipaddress")
            }
        }.getOrNull()
    }

    /** Muss innerhalb ~30 s nach Druck auf die Bridge-Taste aufgerufen werden. Liefert (username, clientkey) oder null. */
    suspend fun pair(ip: String): Pair<String, String>? = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().put("devicetype", "huesynctv#sony").put("generateclientkey", true)
                .toString().toRequestBody(JSON)
            val req = Request.Builder().url("https://$ip/api").post(body).build()
            bridgeClient.newCall(req).execute().use {
                val ok = JSONArray(it.body!!.string()).getJSONObject(0).optJSONObject("success")
                    ?: return@use null
                ok.getString("username") to ok.getString("clientkey")
            }
        }.getOrNull()
    }

    private fun v2(ip: String, key: String, path: String) =
        Request.Builder().url("https://$ip/clip/v2/resource/$path").header("hue-application-key", key)

    suspend fun zones(ip: String, key: String): List<Zone> = withContext(Dispatchers.IO) {
        runCatching {
            bridgeClient.newCall(v2(ip, key, "entertainment_configuration").build()).execute().use {
                val data = JSONObject(it.body!!.string()).getJSONArray("data")
                (0 until data.length()).map { i ->
                    val z = data.getJSONObject(i)
                    val chs = z.getJSONArray("channels")
                    Zone(
                        id = z.getString("id"),
                        name = z.getJSONObject("metadata").getString("name"),
                        channels = (0 until chs.length()).map { c ->
                            val ch = chs.getJSONObject(c)
                            val p = ch.getJSONObject("position")
                            Channel(ch.getInt("channel_id"), p.getDouble("x"), p.getDouble("y"))
                        }
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    /** Schaltet den Streaming-Modus des Entertainment-Bereichs ein/aus (vor dem DTLS-Connect nötig). */
    suspend fun setStreaming(ip: String, key: String, zoneId: String, start: Boolean): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val body = JSONObject().put("action", if (start) "start" else "stop").toString().toRequestBody(JSON)
                val req = v2(ip, key, "entertainment_configuration/$zoneId").put(body).build()
                bridgeClient.newCall(req).execute().use { it.isSuccessful }
            }.getOrDefault(false)
        }
}
