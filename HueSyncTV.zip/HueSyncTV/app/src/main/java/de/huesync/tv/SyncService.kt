package de.huesync.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import kotlinx.coroutines.*

/**
 * Greift per MediaProjection den Bildschirm ab (klein skaliert), berechnet pro Hue-Kanal eine Farbe
 * aus der passenden Bildregion und streamt sie mit ~25 Hz an die Bridge.
 * DRM-Inhalte (Netflix & Co.) erscheinen schwarz – dann bleiben die Lichter einfach dunkel.
 */
class SyncService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var streamer: HueStreamer? = null
    private var zone: Zone? = null
    private var ip = ""
    private var user = ""
    private var zoneId = ""

    @Volatile private var target: Map<Int, FloatArray> = emptyMap()

    private val w = 96
    private val h = 54

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }

        startInForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        val p = getSharedPreferences("hue", MODE_PRIVATE)
        ip = p.getString("ip", "") ?: ""
        user = p.getString("user", "") ?: ""
        val clientKey = p.getString("key", "") ?: ""
        zoneId = p.getString("zone", "") ?: ""
        if (data == null || ip.isEmpty() || user.isEmpty() || zoneId.isEmpty()) { shutdown(); return START_NOT_STICKY }

        scope.launch {
            zone = Hue.zones(ip, user).firstOrNull { it.id == zoneId }
            val z = zone ?: run { shutdown(); return@launch }
            if (!Hue.setStreaming(ip, user, zoneId, true)) { shutdown(); return@launch }

            streamer = HueStreamer(ip, user, clientKey, zoneId).also { it.start() }
            withContext(Dispatchers.Main) { startCapture(code, data) }
            runSendLoop(z)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { shutdown() }
            }, Handler(mainLooper))
        }
        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = img.planes[0]
                    zone?.let { target = analyze(plane.buffer, plane.rowStride, plane.pixelStride, it) }
                } finally { img.close() }
            }, handler)
        }
        val dpi = resources.displayMetrics.densityDpi
        display = projection!!.createVirtualDisplay(
            "huesync", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
    }

    /** Pro Kanal: Mittelwert eines Fensters um die Kanalposition (x,y in -1..1 -> Bildschirm). */
    private fun analyze(buf: java.nio.ByteBuffer, rowStride: Int, pixStride: Int, z: Zone): Map<Int, FloatArray> {
        val out = HashMap<Int, FloatArray>()
        val rx = (w * 0.22f).toInt().coerceAtLeast(2)
        val ry = (h * 0.30f).toInt().coerceAtLeast(2)
        for (c in z.channels) {
            val cx = (((c.x + 1) / 2) * (w - 1)).toInt()
            val cy = (((1 - c.y) / 2) * (h - 1)).toInt()   // Hue: y nach oben
            var r = 0L; var g = 0L; var b = 0L; var n = 0
            for (yy in (cy - ry).coerceAtLeast(0)..(cy + ry).coerceAtMost(h - 1) step 2) {
                for (xx in (cx - rx).coerceAtLeast(0)..(cx + rx).coerceAtMost(w - 1) step 2) {
                    val o = yy * rowStride + xx * pixStride
                    r += buf.get(o).toInt() and 0xFF
                    g += buf.get(o + 1).toInt() and 0xFF
                    b += buf.get(o + 2).toInt() and 0xFF
                    n++
                }
            }
            if (n > 0) out[c.id] = floatArrayOf(r / n.toFloat(), g / n.toFloat(), b / n.toFloat())
        }
        return out
    }

    private suspend fun runSendLoop(z: Zone) {
        val cur = HashMap<Int, FloatArray>()
        val smooth = 0.35f
        while (scope.isActive) {
            val t = target
            val colors = HashMap<Int, Triple<Int, Int, Int>>()
            for (c in z.channels) {
                val tc = t[c.id] ?: floatArrayOf(0f, 0f, 0f)
                val cc = cur.getOrPut(c.id) { floatArrayOf(0f, 0f, 0f) }
                for (i in 0..2) cc[i] += (tc[i] - cc[i]) * smooth
                colors[c.id] = Triple(cc[0].toInt(), cc[1].toInt(), cc[2].toInt())
            }
            streamer?.send(colors)      // sendet auch bei statischem Bild weiter (Bridge beendet Stream nach ~10 s Stille)
            delay(40)
        }
    }

    private fun shutdown() {
        scope.cancel()
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        thread?.quitSafely(); thread = null
        streamer?.stop(); streamer = null
        val ip0 = ip; val u = user; val z = zoneId
        if (ip0.isNotEmpty() && z.isNotEmpty()) {
            GlobalScope.launch(Dispatchers.IO) { Hue.setStreaming(ip0, u, z, false) }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sync", "Hue Sync", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "sync")
            .setContentTitle("Hue Sync läuft")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object { const val ACTION_STOP = "de.huesync.tv.STOP" }
}
