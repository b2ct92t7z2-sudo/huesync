package de.huesync.tv

import android.app.AlertDialog
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var status: TextView
    private lateinit var ipField: EditText
    private val prefs by lazy { getSharedPreferences("hue", Context.MODE_PRIVATE) }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            val i = Intent(this, SyncService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data)
            startForegroundService(i)
            setStatus("Sync läuft. Zum Beenden hier „Stoppen“ wählen.")
        } else setStatus("Bildschirmaufnahme nicht erlaubt (oder auf diesem TV nicht verfügbar).")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(80, 48, 80, 48)
        }
        status = TextView(this).apply { textSize = 20f }
        ipField = EditText(this).apply { hint = "Bridge-IP"; setText(prefs.getString("ip", "")); isSingleLine = true }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isFocusable = true; setOnClickListener { onClick() }
        }

        root.addView(status)
        root.addView(ipField)
        root.addView(btn("1. Bridge suchen") { findBridge() })
        root.addView(btn("2. Koppeln (vorher Taste an der Bridge drücken)") { pair() })
        root.addView(btn("3. Entertainment-Bereich wählen") { pickZone() })
        root.addView(btn("4. Sync starten") { startSync() })
        root.addView(btn("Stoppen") {
            startService(Intent(this, SyncService::class.java).setAction(SyncService.ACTION_STOP))
            setStatus("Gestoppt.")
        })
        setContentView(root)
        refreshStatus()
    }

    private fun setStatus(s: String) { status.text = s }

    private fun refreshStatus() {
        val paired = !prefs.getString("user", "").isNullOrEmpty()
        val zone = prefs.getString("zoneName", null)
        setStatus("Bridge: ${prefs.getString("ip", "–")} | Gekoppelt: ${if (paired) "ja" else "nein"} | Bereich: ${zone ?: "–"}")
    }

    private fun findBridge() = scope.launch {
        setStatus("Suche Bridge …")
        val ip = Hue.discover()
        if (ip != null) { ipField.setText(ip); prefs.edit().putString("ip", ip).apply(); refreshStatus() }
        else setStatus("Nicht gefunden – IP bitte manuell eintragen.")
    }

    private fun pair() = scope.launch {
        val ip = ipField.text.toString().trim()
        if (ip.isEmpty()) { setStatus("Erst Bridge-IP eintragen."); return@launch }
        prefs.edit().putString("ip", ip).apply()
        setStatus("Drücke jetzt die Taste an der Bridge … (30 s)")
        repeat(15) {
            val r = Hue.pair(ip)
            if (r != null) {
                prefs.edit().putString("user", r.first).putString("key", r.second).apply()
                refreshStatus(); return@launch
            }
            delay(2000)
        }
        setStatus("Koppeln fehlgeschlagen – Taste nicht gedrückt?")
    }

    private fun pickZone() = scope.launch {
        val ip = prefs.getString("ip", "") ?: ""
        val user = prefs.getString("user", "") ?: ""
        if (user.isEmpty()) { setStatus("Erst koppeln."); return@launch }
        val zones = Hue.zones(ip, user)
        if (zones.isEmpty()) { setStatus("Keine Entertainment-Bereiche. In der Hue-App einen anlegen."); return@launch }
        AlertDialog.Builder(this@MainActivity)
            .setTitle("Entertainment-Bereich")
            .setItems(zones.map { "${it.name} (${it.channels.size} Lichter)" }.toTypedArray()) { _, i ->
                prefs.edit().putString("zone", zones[i].id).putString("zoneName", zones[i].name).apply()
                refreshStatus()
            }.show()
    }

    private fun startSync() {
        if (prefs.getString("zone", null).isNullOrEmpty()) { setStatus("Erst Bereich wählen."); return }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try { projectionLauncher.launch(mgr.createScreenCaptureIntent()) }
        catch (e: Exception) { setStatus("Dieser TV bietet keine Bildschirmaufnahme an.") }
    }

    override fun onDestroy() { scope.coroutineContext[kotlinx.coroutines.Job]?.cancel(); super.onDestroy() }
}
