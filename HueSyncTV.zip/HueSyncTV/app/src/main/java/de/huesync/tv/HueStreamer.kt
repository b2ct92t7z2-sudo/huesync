package de.huesync.tv

import org.eclipse.californium.elements.AddressEndpointContext
import org.eclipse.californium.elements.EndpointContext
import org.eclipse.californium.elements.MessageCallback
import org.eclipse.californium.elements.RawData
import org.eclipse.californium.elements.config.Configuration
import org.eclipse.californium.scandium.DTLSConnector
import org.eclipse.californium.scandium.config.DtlsConfig
import org.eclipse.californium.scandium.config.DtlsConnectorConfig
import org.eclipse.californium.scandium.dtls.cipher.CipherSuite
import org.eclipse.californium.scandium.dtls.pskstore.AdvancedSinglePskStore
import java.net.InetSocketAddress

/**
 * Hue Entertainment API v2: DTLS 1.2 (PSK, TLS_PSK_WITH_AES_128_GCM_SHA256) auf UDP 2100.
 * PSK-Identity = Application-Key (username), PSK = clientkey (Hex).
 */
class HueStreamer(
    private val ip: String,
    private val username: String,
    private val clientKeyHex: String,
    private val zoneId: String,
) {
    private var connector: DTLSConnector? = null
    private val target = InetSocketAddress(ip, 2100)
    private var seq = 0

    @Volatile var ready = false
        private set
    @Volatile private var sending = false

    fun start() {
        DtlsConfig.register()
        val key = clientKeyHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val cfg = DtlsConnectorConfig.builder(Configuration.getStandard())
            .set(DtlsConfig.DTLS_CIPHER_SUITES, listOf(CipherSuite.TLS_PSK_WITH_AES_128_GCM_SHA256))
            .set(DtlsConfig.DTLS_ROLE, DtlsConfig.DtlsRole.CLIENT_ONLY)
            .setAdvancedPskStore(AdvancedSinglePskStore(username, key))
            .build()
        connector = DTLSConnector(cfg).also { it.start() }
    }

    /** colors: Channel-ID -> RGB (0..255). Der erste Aufruf löst den DTLS-Handshake aus. */
    fun send(colors: Map<Int, Triple<Int, Int, Int>>) {
        val c = connector ?: return
        if (sending) return
        val msg = build(colors)
        sending = true
        c.send(RawData.outbound(msg, AddressEndpointContext(target), object : MessageCallback {
            override fun onContextEstablished(context: EndpointContext?) { ready = true }
            override fun onSent() { ready = true; sending = false }
            override fun onError(error: Throwable?) { ready = false; sending = false }
        }, false))
    }

    private fun build(colors: Map<Int, Triple<Int, Int, Int>>): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        out.write("HueStream".toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf(0x02, 0x00))            // Version 2.0
        out.write(seq++ and 0xFF)                      // Sequenznummer
        out.write(byteArrayOf(0x00, 0x00))            // reserviert
        out.write(0x00)                                // Farbraum: RGB
        out.write(0x00)                                // reserviert
        out.write(zoneId.toByteArray(Charsets.US_ASCII)) // 36 Zeichen UUID
        for ((id, rgb) in colors) {
            out.write(id)
            for (v in listOf(rgb.first, rgb.second, rgb.third)) {
                val v16 = v.coerceIn(0, 255) * 257      // 8 -> 16 Bit
                out.write(v16 shr 8); out.write(v16 and 0xFF)
            }
        }
        return out.toByteArray()
    }

    fun stop() {
        connector?.destroy()
        connector = null
        ready = false
    }
}
