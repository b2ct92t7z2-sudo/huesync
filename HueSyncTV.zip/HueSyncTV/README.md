# Hue Sync TV (Sony Google TV / Android TV)

Synchronisiert Hue-Lichter (über die Bridge, Entertainment API) mit dem Bildschirminhalt.

## Voraussetzungen
- Hue Bridge v2, ein in der Hue-App angelegter **Entertainment-Bereich**
- Sony-TV mit Google TV / Android TV (API 28+), im selben Netzwerk
- Android Studio (Hedgehog oder neuer), JDK 17

## Bauen & installieren
1. Projektordner in Android Studio öffnen, Gradle-Sync abwarten.
2. TV: Entwickleroptionen + ADB-Debugging aktivieren (Einstellungen > Geräteeinstellungen > Info > mehrmals auf „Build“).
3. `adb connect <TV-IP>` und dann in Android Studio auf den TV deployen (oder `./gradlew installDebug`).

## Benutzung
1. „Bridge suchen“ → 2. „Koppeln“ (Bridge-Taste drücken) → 3. Bereich wählen → 4. „Sync starten“ und Aufnahme erlauben.

## Grenzen
- DRM-Inhalte (Netflix, Disney+, Prime …) und HDMI-Eingänge sind für die Bildschirmaufnahme schwarz.
- Manche TV-Firmware bietet MediaProjection nicht an; dann zeigt die App eine Meldung.
- Der Code wurde noch nicht auf einem echten TV getestet.
